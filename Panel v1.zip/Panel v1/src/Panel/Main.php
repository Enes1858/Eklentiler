<?php

namespace Panel;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use jojoe77777\FormAPI;

class Main extends PluginBase{
	
	public function onEnable(){
		$this->getLogger()->info("§aPanel Plugin Aktif");
	}
	
	public function onCommand(CommandSender $oyuncu, Command $command, string $label, array $args): bool{
		if($command->getName() == "panel"){
			$this->pForm($oyuncu);
		}
		return true;
	}
	
	public function pForm(Player $oyuncu){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createCustomForm(function(Player $oyuncu, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			
			switch($re){
				case 0:
				$oyuncu->sendMessage("§4Çıkış Yapıldı");
				break;
			}
			switch($re){
				case 1:
				$this->oForm($oyuncu);
				break;
			}
			switch($re){
				case 2:
				if($oyuncu->hasPermission("vip.panel")){
				$this->vipForm($oyuncu);
				}else{
					$oyuncu->sendMessage("§4Yetkiniz Kontrol Ediliyor Bekleyiniz....\n§4Yetkiniz Bu Paneli Açmaya Yetmiyor.");
				}
				break;
			}
			switch($re){
				case 3:
				if($oyuncu->hasPermission("vipp.panel")){
				$this->vippForm($oyuncu);
				}else{
					$oyuncu->sendMessage("§4Yetkiniz Kontrol Ediliyor Bekleyiniz....\n§4Yetkiniz Bu Paneli Açmaya Yetmiyor.");
				}
				break;
			}
			switch($re){
				case 4:
				if($oyuncu->hasPermission("mvip.panel")){
				$this->mvipForm($oyuncu);
				}else{
					$oyuncu->sendMessage("§4Yetkiniz Kontrol Ediliyor Bekleyiniz....\n§4Yetkiniz Bu Paneli Açmaya Yetmiyor.");
				}
				break;
			}
		});
		
	 $isim = $oyuncu->getName();
	$f->setTitle("§3Panel Menüsü");
	$f->addDropdown("§4Panel Menüsüne Hoşgeldin §f$isim", ["§4Çıkış", "§7Oyuncu", "§6VIP", "§6VIP§1+", "§6MVIP"]);
	$f->addLabel("");
	$f->sendToPlayer($oyuncu);
	}
	
	public function oForm(Player $oyuncu){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createCustomForm(function(Player $oyuncu, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			
			switch($re){
				case 0:
				$oyuncu->sendMessage("§4Çıkış Yapıldı");
				break;
				case 1:
				$oyuncu->setAllowFlight(true);
				break;
				case 2:
				$oyuncu->setAllowFlight(false);
				break;
			}
		});
		
		$f->setTitle("§7Oyuncu Paneli");
		$f->addDropdown("§7İslemin Nedir", ["§4Çıkış", "§7Fly Aç", "§7Fly Kapat"]);
		$f->addLabel("");
		$f->sendToPlayer($oyuncu);
	}
	
	public function vipForm(Player $oyuncu){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createCustomForm(function(Player $oyuncu, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			
			switch($re){
				case 0:
				$oyuncu->sendMessage("§4Çıkış Yapıldı");
				break;
				case 1:
				$oyuncu->setAllowFlight(true);
				break;
				case 2:
				$oyuncu->setAllowFlight(false);
				break;
				case 3:
				$oyuncu->setHealt(20);
				break;
				case 4:
				$oyuncu->setFood(20);
				break;
			}
		});
		
		$f->setTitle("§6VIP §7Paneli");
		$f->addDropdown("§7İslemin Nedir", ["§4Çıkış", "§7Fly Aç", "§7Fly Kapat", "§7Can Doldur", "§7Açlık Doldur"]);
		$f->addLabel("");
		$f->sendToPlayer($oyuncu);
	}
	
	public function vippForm(Player $oyuncu){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createCustomForm(function(Player $oyuncu, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			
			switch($re){
				case 0:
				$oyuncu->sendMessage("§4Çıkış Yapıldı");
				break;
				case 1:
				$oyuncu->setAllowFlight(true);
				break;
				case 2:
				$oyuncu->setAllowFlight(false);
				break;
				case 3:
				$oyuncu->setHealt(20);
				break;
				case 4:
				$oyuncu->setFood(20);
				break;
			}
		});
		
		$f->setTitle("§6VIP§1+ §7Paneli");
		$f->addDropdown("§7İslemin Nedir", ["§4Çıkış", "§7Fly Aç", "§7Fly Kapat", "§7Can Doldur", "§7Açlık Doldur"]);
		$f->addLabel("");
		$f->sendToPlayer($oyuncu);
	}
	
	public function mvipForm(Player $oyuncu){
		$f = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createCustomForm(function(Player $oyuncu, array $data){
			$re = $data[0];
			if($re === null){
				return true;
			}
			
			switch($re){
				case 0:
				$oyuncu->sendMessage("§4Çıkış Yapıldı");
				break;
				case 1:
				$oyuncu->setAllowFlight(true);
				break;
				case 2:
				$oyuncu->setAllowFlight(false);
				break;
				case 3:
				$oyuncu->setHealt(20);
				break;
				case 4:
				$oyuncu->setFood(20);
				break;
				case 5:
				$oyuncu->sendMessage("§41 Saniye Eşyanız Tamir Ediliyor...\n§aEşyanız Tamir Edildi");
				$item = $oyuncu->getInventory()->getItemHand();
				$item->setDamage(0);
				break;
			}
		});
		
		$f->setTitle("§6MVIP §7Paneli");
		$f->addDropdown("§7İslemin Nedir", ["§4Çıkış", "§7Fly Aç", "§7Fly Kapat", "§7Can Doldur", "§7Açlık Doldur", "§7Tamir"]);
		$f->addLabel("");
		$f->sendToPlayer($oyuncu);
	}
}